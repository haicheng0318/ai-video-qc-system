'use client';

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { apiBaseUrl, apiFetch, getToken } from '@/lib/api';
import { ApiUser } from '@/lib/api';
import { loadVideoDetailRequests } from '@/lib/video-detail-loader';
import { SupervisorReviewPanel, SupervisorReviewView } from '@/components/supervisor-review-panel';
import { VideoRevisionPanel } from '@/components/video-revision-panel';
import { VideoVersionChain } from '@/components/video-version-chain';
import { canSubmitSupervisorReview } from '@/lib/supervisor-review-ui';
import { ResultMetricsPanel } from '@/components/result-metrics-panel';
import { VideoType } from '@ai-video-qc/shared';
import { ResultReviewPanel } from '@/components/result-review-panel';
import { RuleEnginePanel } from '@/components/rule-engine-panel';
import { FinalEvaluationPanel } from '@/components/final-evaluation-panel';
import { FinalConfirmationPanel } from '@/components/final-confirmation-panel';
import {
  displayLabel,
  operationLogActionLabels,
  operationLogDescription,
  priorityLabels,
  reviewStatusLabels,
  severityLabels,
  userFacingErrorMessage,
  videoStatusLabels,
  videoTypeLabels,
} from '@/lib/display-labels';

type ContentReviewScore = {
  id: string;
  dimension: string;
  score: number;
  maxScore: number;
  comment?: string | null;
};

type ContentReview = {
  id: string;
  modelProvider: string;
  modelName: string;
  contentSummary?: string | null;
  totalScore?: number | null;
  contentGrade?: string | null;
  isPublishableRecommendation?: boolean | null;
  mainProblems?: Array<{ dimension: string; description: string; timestamp?: string | null; severity: string }> | null;
  revisionSuggestions?: Array<{ problem: string; suggestion: string; priority: string }> | null;
  complianceRisks?: Array<{ riskType: string; description: string; timestamp?: string | null }> | null;
  usableScenarios?: string[] | null;
  status: string;
  errorMessage?: string | null;
  createdAt: string;
  scores: ContentReviewScore[];
};

type VideoDetail = {
  id: string;
  title: string;
  brand?: string;
  product?: string;
  platform?: string;
  videoType: VideoType;
  status: string;
  scriptDescription?: string;
  isForAds: boolean;
  isEventVideo: boolean;
  eventName?: string;
  createdAt: string;
  creator?: {
    id: string;
    name: string;
    account: string;
  };
  aiContentReviews?: unknown[];
  supervisorReview?: SupervisorReviewView | null;
  resultMetrics?: unknown[];
  aiResultReviews?: unknown[];
  ruleEngineResults?: unknown[];
  finalVideoEvaluations?: unknown[];
  operationLogs?: Array<{ id: string; actionType: string; createdAt: string; comment?: string }>;
  parentVideo?: VersionLink | null;
  revisions?: VersionLink[];
  versionChain?: VersionLink[];
};

type VersionLink = { id: string; title: string; status: string; version: number };

export default function VideoDetailPage({ params }: { params: { id: string } }) {
  const [video, setVideo] = useState<VideoDetail | null>(null);
  const [contentReview, setContentReview] = useState<ContentReview | null>(null);
  const [videoUrl, setVideoUrl] = useState('');
  const [error, setError] = useState('');
  const [reviewLoading, setReviewLoading] = useState(false);
  const [reviewError, setReviewError] = useState('');
  const [latestError, setLatestError] = useState('');
  const [currentUser, setCurrentUser] = useState<ApiUser | null>(null);
  const [supervisorReview, setSupervisorReview] = useState<SupervisorReviewView | null>(null);

  const loadVideo = useCallback(async () => {
    setLatestError('');
    await loadVideoDetailRequests({
      loadDetail: () => apiFetch<VideoDetail>(`/api/videos/${params.id}`),
      loadLatest: () => apiFetch<{ review: ContentReview | null }>(`/api/videos/${params.id}/content-review/latest`),
      onDetail: setVideo,
      onLatest: (latest) => setContentReview(latest.review),
      onLatestError: () => setLatestError('评估结果暂时不可用，请稍后重试。'),
    });
    const [userResult, supervisorResult] = await Promise.allSettled([
      apiFetch<{ user: ApiUser }>('/api/auth/me'),
      apiFetch<SupervisorReviewView | null>(`/api/videos/${params.id}/supervisor-review/latest`),
    ]);
    if (userResult.status === 'fulfilled') setCurrentUser(userResult.value.user);
    if (supervisorResult.status === 'fulfilled') setSupervisorReview(supervisorResult.value);
  }, [params.id]);

  useEffect(() => {
    loadVideo().catch((err) => setError(err instanceof Error ? err.message : '加载失败'));
  }, [loadVideo]);

  useEffect(() => {
    const token = getToken();
    if (!token) return;

    fetch(`${apiBaseUrl}/api/videos/${params.id}/file`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => {
        if (!response.ok) throw new Error('视频文件加载失败');
        return response.blob();
      })
      .then((blob) => {
        const url = URL.createObjectURL(blob);
        setVideoUrl(url);
      })
      .catch((err) => setError(err instanceof Error ? err.message : '视频文件加载失败'));
  }, [params.id]);

  async function triggerContentReview() {
    setReviewLoading(true);
    setReviewError('');
    try {
      await apiFetch(`/api/videos/${params.id}/content-review`, { method: 'POST' });
      await loadVideo();
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : '内容评估失败');
      await loadVideo().catch(() => undefined);
    } finally {
      setReviewLoading(false);
    }
  }

  if (error) {
    return (
      <main className="page">
        <p className="error">{error}</p>
      </main>
    );
  }

  if (!video) {
    return (
      <main className="page">
        <p className="muted">加载中</p>
      </main>
    );
  }

  const canTriggerReview =
    (video.status === 'submitted' || video.status === 'ai_content_failed') &&
    Boolean(
      currentUser &&
        (currentUser.role === 'admin' ||
          currentUser.role === 'content_owner' ||
          (currentUser.role === 'director' && currentUser.id === video.creator?.id)),
    );
  const canReview = canSubmitSupervisorReview(currentUser, video.status);
  const canUploadRevision =
    video.status === 'revision_required' &&
    Boolean(
      currentUser &&
        (currentUser.id === video.creator?.id ||
          currentUser.role === 'admin' ||
          currentUser.role === 'content_owner'),
    );

  return (
    <main className="page">
      <div className="page-title">
        <div>
          <h1>{video.title}</h1>
          <p className="muted">
            {video.creator?.name || '-'} · {new Date(video.createdAt).toLocaleString()}
          </p>
        </div>
        <Link className="button secondary" href="/videos">
          返回列表
        </Link>
      </div>
      <div className="detail-grid">
        <section className="panel">
          {videoUrl ? <video src={videoUrl} controls /> : <p className="muted">视频加载中</p>}
        </section>
        <aside className="panel">
          <h2>基础信息</h2>
          <p>状态：{displayLabel(videoStatusLabels, video.status)}</p>
          <p>视频类型：{displayLabel(videoTypeLabels, video.videoType)}</p>
          <p>品牌：{video.brand || '-'}</p>
          <p>产品：{video.product || '-'}</p>
          <p>平台：{video.platform || '-'}</p>
          <p>用于投放：{video.isForAds ? '是' : '否'}</p>
          <p>节点视频：{video.isEventVideo ? '是' : '否'}</p>
          <p>节点名称：{video.eventName || '-'}</p>
        </aside>
      </div>
      <section className="panel" style={{ marginTop: 20 }}>
        <div className="page-title">
          <div>
            <h2>Qwen-Omni 内容评估</h2>
            <p className="muted">
              {contentReview ? displayLabel(reviewStatusLabels, contentReview.status) : '未评估'}
            </p>
          </div>
          {canTriggerReview ? (
            <button className="button" type="button" onClick={triggerContentReview} disabled={reviewLoading}>
              {reviewLoading ? '评估中...' : '触发内容评估'}
            </button>
          ) : null}
        </div>
        {reviewError ? <p className="error">{reviewError}</p> : null}
        {latestError ? <p className="error">{latestError}</p> : null}
        {contentReview?.status === 'failed' ? <p className="error">{userFacingErrorMessage(contentReview.errorMessage, '内容评估失败，请稍后重试。')}</p> : null}
        {contentReview?.status === 'succeeded' ? (
          <div>
            <p>内容总分：{contentReview.totalScore ?? '-'}</p>
            <p>内容等级：{contentReview.contentGrade || '-'}</p>
            <p>建议发布：{contentReview.isPublishableRecommendation ? '是' : '否'}</p>
            <p>内容摘要：{contentReview.contentSummary || '-'}</p>
            <h3>维度评分</h3>
            <ul>
              {contentReview.scores.map((score) => (
                <li key={score.id}>{score.dimension}：{score.score}/{score.maxScore}，{score.comment || '-'}</li>
              ))}
            </ul>
            <h3>主要问题</h3>
            <ul>
              {(contentReview.mainProblems || []).map((problem, index) => (
                <li key={`${problem.dimension}-${index}`}>{problem.dimension}：{problem.description}（严重程度：{displayLabel(severityLabels, problem.severity)}）</li>
              ))}
            </ul>
            <h3>修改建议</h3>
            <ul>
              {(contentReview.revisionSuggestions || []).map((suggestion, index) => (
                <li key={`${suggestion.problem}-${index}`}>{suggestion.problem}：{suggestion.suggestion}（{displayLabel(priorityLabels, suggestion.priority)}）</li>
              ))}
            </ul>
            <h3>合规风险</h3>
            <ul>
              {(contentReview.complianceRisks || []).map((risk, index) => (
                <li key={`${risk.riskType}-${index}`}>{risk.riskType}：{risk.description}</li>
              ))}
            </ul>
            <h3>可使用场景</h3>
            <p>{(contentReview.usableScenarios || []).join('、') || '-'}</p>
          </div>
        ) : null}
      </section>
      <SupervisorReviewPanel
        videoId={video.id}
        canReview={canReview}
        review={supervisorReview || video.supervisorReview || null}
        onCompleted={loadVideo}
      />
      {canUploadRevision && (supervisorReview || video.supervisorReview) ? (
        <VideoRevisionPanel
          parentVideoId={video.id}
          comment={(supervisorReview || video.supervisorReview)?.comment || null}
          requirements={(supervisorReview || video.supervisorReview)?.revisionRequirements || []}
        />
      ) : null}
      <VideoVersionChain
        currentId={video.id}
        chain={video.versionChain || []}
        parent={video.parentVideo || null}
        revisions={video.revisions || []}
      />
      <ResultMetricsPanel
        videoId={video.id}
        videoType={video.videoType}
        isForAds={video.isForAds}
        videoStatus={video.status}
        currentUser={currentUser}
        onVideoRefresh={loadVideo}
      />
      <ResultReviewPanel
        videoId={video.id}
        videoType={video.videoType}
        isForAds={video.isForAds}
        videoStatus={video.status}
        currentUser={currentUser}
        onVideoRefresh={loadVideo}
      />
      <RuleEnginePanel
        videoId={video.id}
        videoStatus={video.status}
        currentUser={currentUser}
        onVideoRefresh={loadVideo}
      />
      <FinalEvaluationPanel
        videoId={video.id}
        videoStatus={video.status}
        currentUser={currentUser}
        onVideoRefresh={loadVideo}
      />
      <FinalConfirmationPanel
        videoId={video.id}
        videoStatus={video.status}
        currentUser={currentUser}
        onVideoRefresh={loadVideo}
      />
      <section className="panel section-gap">
        <h2>操作日志</h2>
        <table className="table">
          <thead>
            <tr>
              <th>动作</th>
              <th>说明</th>
              <th>时间</th>
            </tr>
          </thead>
          <tbody>
            {(video.operationLogs || []).map((log) => (
              <tr key={log.id}>
                <td>{displayLabel(operationLogActionLabels, log.actionType)}</td>
                <td>{operationLogDescription(log.actionType, log.comment)}</td>
                <td>{new Date(log.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </main>
  );
}
