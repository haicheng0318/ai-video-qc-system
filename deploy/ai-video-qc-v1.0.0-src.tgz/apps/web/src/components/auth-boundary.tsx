'use client';

import { ReactNode, useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { apiFetch, getToken } from '@/lib/api';

export function AuthBoundary({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [authorized, setAuthorized] = useState(pathname === '/login');

  useEffect(() => {
    let active = true;
    if (pathname === '/login') {
      setAuthorized(true);
      return () => { active = false; };
    }

    setAuthorized(false);
    if (!getToken()) {
      router.replace('/login');
      return () => { active = false; };
    }

    void apiFetch('/api/auth/me')
      .then(() => {
        if (active) setAuthorized(true);
      })
      .catch(() => {
        if (active) router.replace('/login');
      });
    return () => { active = false; };
  }, [pathname, router]);

  if (!authorized) {
    return (
      <main className="page">
        <div className="panel">正在验证登录状态……</div>
      </main>
    );
  }

  return children;
}
