type ApiRequest = (path: string, init?: RequestInit) => Promise<unknown>;

type UploadTicket = {
  uploadUrl: string;
  objectPath: string;
  headers: Record<string, string>;
};

function requiredVideoFile(formData: FormData) {
  const file = formData.get('file');
  if (!(file instanceof File) || file.size < 1) throw new Error('请选择视频文件。');
  return file;
}

function formDataPayload(formData: FormData) {
  const payload: Record<string, FormDataEntryValue | boolean> = {};
  for (const [key, value] of formData.entries()) {
    if (key !== 'file') payload[key] = value;
  }
  payload.isForAds = formData.has('isForAds');
  payload.isEventVideo = formData.has('isEventVideo');
  return payload;
}

export function usesDirectVideoUpload() {
  return process.env.NEXT_PUBLIC_VIDEO_UPLOAD_MODE === 'direct';
}

export async function uploadVideoDirectly(
  request: ApiRequest,
  formData: FormData,
  finalizePath: string,
): Promise<{ id: string }> {
  const file = requiredVideoFile(formData);
  const ticket = await request('/api/videos/direct-upload-ticket', {
    method: 'POST',
    body: JSON.stringify({ fileName: file.name, mimeType: file.type, fileSizeBytes: file.size }),
  }) as UploadTicket;

  const upload = await fetch(ticket.uploadUrl, {
    method: 'PUT',
    headers: ticket.headers,
    body: file,
  });
  if (!upload.ok) throw new Error(`视频上传到存储服务失败（${upload.status}）。`);

  return request(finalizePath, {
    method: 'POST',
    body: JSON.stringify({
      ...formDataPayload(formData),
      objectPath: ticket.objectPath,
      originalFileName: file.name,
      mimeType: file.type,
      fileSizeBytes: file.size,
    }),
  }) as Promise<{ id: string }>;
}
