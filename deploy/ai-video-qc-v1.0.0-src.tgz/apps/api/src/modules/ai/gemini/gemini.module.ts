import { Module } from '@nestjs/common';
import { PermissionsModule } from '../../permissions/permissions.module';
import { QwenClient, QWEN_CLIENT } from './qwen.client';
import { ContentReviewService } from './gemini.service';

@Module({
  imports: [PermissionsModule],
  providers: [
    {
      provide: QWEN_CLIENT,
      useFactory: () => new QwenClient(),
    },
    ContentReviewService,
  ],
  exports: [ContentReviewService],
})
export class ContentReviewModule {}
