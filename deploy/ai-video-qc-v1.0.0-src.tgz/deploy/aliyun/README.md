# 阿里云 ECS 独立部署

此目录用于将“AI短视频质检评估系统 V1.0”独立部署到阿里云 ECS，不与“视频需求数据看板”共享代码、数据库或运行环境。

- Caddy：HTTPS 入口及同源反向代理
- Next.js：前端
- NestJS：后端 API
- PostgreSQL：独立数据库
- ECS Docker Volume：视频、封面和数据库持久化
- 阿里云 OSS：仅作为 Qwen-Omni 读取视频时的临时中转

复制 `.env.example` 为 `.env` 并填写服务端密钥，然后执行：

```bash
docker compose -f deploy/aliyun/compose.yaml --env-file deploy/aliyun/.env up -d --build
```

生产密钥只允许写入服务器端 `deploy/aliyun/.env`。该文件已由仓库根目录 `.dockerignore` 排除，且不应提交到 Git。
