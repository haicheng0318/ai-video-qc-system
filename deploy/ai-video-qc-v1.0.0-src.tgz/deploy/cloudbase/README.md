# CloudBase 生产部署

本目录只用于独立的 `ai-video-qc-prod` 环境，不得指向或更改
`video-dashboard-d9f7jezmf964f443` 环境。

## 资源边界

- CloudBase Run 前端服务：`ai-video-qc-web`
- CloudBase Run 后端服务：`ai-video-qc-api`
- 独立 CloudBase PostgreSQL 环境，只通过同地域 VPC 内网访问
- 独立私有 COS Bucket，用于永久视频存储
- 独立私有阿里云 OSS Bucket，仅作 Qwen 视频评估的临时中转

## 运行约束

- API 服务必须设置最小实例数 1，不得缩容到 0。
- 生产视频由浏览器使用后端短时签名 URL 直传私有 COS，避开 CloudBase Run 20MB 请求体限制。
- 对外只发布 CloudBase HTTPS 域名；PostgreSQL 不开放公网。
- 所有真实密钥只在后端服务环境变量中配置。
- COS 和 OSS Bucket 均必须为私有，并使用独立最小权限身份。
- OSS 临时前缀设置 1 天自动清理生命周期。
- COS CORS 仅允许 Web 正式域名的 `PUT`/`HEAD` 请求和 `Content-Type` 请求头。

## 发布顺序

1. 创建独立 CloudBase 环境、VPC、PostgreSQL、COS 和 OSS。
2. API 容器启动时自动执行幂等 Prisma 生产迁移和 seed；初始管理员密码由服务端环境变量提供，后续重启不会覆盖已修改的密码。
3. 先发布 API 镜像，配置环境变量并通过 `/api/health` 检查。
4. 用 API HTTPS 域名构建并发布 Web 镜像。
5. 将 API `WEB_ORIGIN` 限制为 Web 正式域名。
6. 执行未登录拦截、登录、上传、播放、真实 AI 评估和结果展示冒烟测试。

## 回滚

将 CloudBase Run 流量切回上一个健康版本。数据库迁移前创建备份，如迁移
不兼容，将应用版本、PostgreSQL 备份与 COS 版本恢复到同一发布点。
