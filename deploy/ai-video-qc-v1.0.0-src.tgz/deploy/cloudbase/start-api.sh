#!/bin/sh
set -eu

cd /app
npx prisma migrate deploy --schema /app/prisma/schema.prisma
npx prisma db seed

cd /app/apps/api
exec node dist/main.js
